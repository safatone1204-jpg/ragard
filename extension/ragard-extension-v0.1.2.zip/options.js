/**
 * Options page script for Ragard extension
 */

// Settings page is now simplified - API configuration is handled automatically
document.addEventListener('DOMContentLoaded', () => {
  // Settings page loaded
});

