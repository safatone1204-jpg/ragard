/**
 * Options page script for Ragard extension
 */

// Load current settings
async function loadSettings() {
  // Check if auto-detect is enabled
  chrome.storage.sync.get(['ragard_auto_detect', 'ragard_api_base_url', 'ragard_web_app_base_url'], (result) => {
    const autoDetect = result.ragard_auto_detect !== false; // Default to true
    const autoDetectCheckbox = document.getElementById('auto-detect');
    const manualConfig = document.getElementById('manual-config');
    const autoDetectInfo = document.getElementById('auto-detect-info');
    
    autoDetectCheckbox.checked = autoDetect;
    
    if (autoDetect) {
      manualConfig.style.display = 'none';
      autoDetectInfo.style.display = 'block';
      // Show current detected values for reference
      window.ragardConfig?.getApiBaseUrl().then(url => {
        document.getElementById('api-base-url').value = url;
      });
      window.ragardConfig?.getWebAppBaseUrl().then(url => {
        document.getElementById('web-app-base-url').value = url;
      });
    } else {
      manualConfig.style.display = 'block';
      autoDetectInfo.style.display = 'none';
      // Load stored values
      const apiUrl = result.ragard_api_base_url || window.ragardConfig?.PROD_API_BASE_URL || 'https://api.ragardai.com';
      const webAppUrl = result.ragard_web_app_base_url || window.ragardConfig?.PROD_WEB_APP_BASE_URL || 'https://ragardai.com';
      document.getElementById('api-base-url').value = apiUrl;
      document.getElementById('web-app-base-url').value = webAppUrl;
    }
  });
}

// Save settings
async function saveSettings() {
  const autoDetect = document.getElementById('auto-detect').checked;
  
  // Save auto-detect setting
  chrome.storage.sync.set({ ragard_auto_detect: autoDetect });
  
  if (!autoDetect) {
    // Manual mode - validate and save URLs
    const apiUrl = document.getElementById('api-base-url').value.trim();
    const webAppUrl = document.getElementById('web-app-base-url').value.trim();
    
    // Validate URLs
    try {
      new URL(apiUrl);
    } catch {
      showStatus('Invalid API Base URL format', 'error');
      return;
    }
    
    try {
      new URL(webAppUrl);
    } catch {
      showStatus('Invalid Web App Base URL format', 'error');
      return;
    }
    
    // Save to config
    if (window.ragardConfig) {
      await window.ragardConfig.setApiBaseUrl(apiUrl);
      await window.ragardConfig.setWebAppBaseUrl(webAppUrl);
      showStatus('Settings saved successfully!', 'success');
    } else {
      showStatus('Error: Config module not loaded', 'error');
    }
  } else {
    // Auto-detect enabled
    showStatus('Auto-detect enabled! The extension will automatically detect the environment.', 'success');
  }
}

// Test connection
async function testConnection() {
  let apiUrl;
  
  const autoDetect = document.getElementById('auto-detect').checked;
  if (autoDetect) {
    // Use detected URL
    apiUrl = await window.ragardConfig?.getApiBaseUrl() || 'https://api.ragardai.com';
  } else {
    apiUrl = document.getElementById('api-base-url').value.trim();
  }
  
  if (!apiUrl) {
    showStatus('Please enter an API Base URL first', 'error');
    return;
  }
  
  // Validate URL format
  try {
    new URL(apiUrl);
  } catch {
    showStatus('Invalid API Base URL format', 'error');
    return;
  }
  
  showStatus('Testing connection...', 'testing');
  
  try {
    const healthUrl = `${apiUrl}/health`;
    const response = await fetch(healthUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      credentials: 'omit',
    });
    
    if (response.ok) {
      const data = await response.json();
      showStatus(`✓ Connection successful! Status: ${data.status || 'healthy'}`, 'success');
    } else {
      showStatus(`✗ Connection failed: ${response.status} ${response.statusText}`, 'error');
    }
  } catch (error) {
    showStatus(`✗ Connection error: ${error.message}`, 'error');
  }
}

// Show status message
function showStatus(message, type) {
  const statusEl = document.getElementById('status');
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
  
  // Auto-hide success messages after 3 seconds
  if (type === 'success') {
    setTimeout(() => {
      statusEl.className = 'status';
      statusEl.textContent = '';
    }, 3000);
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  
  // Toggle manual config visibility based on auto-detect checkbox
  document.getElementById('auto-detect').addEventListener('change', (e) => {
    const manualConfig = document.getElementById('manual-config');
    const autoDetectInfo = document.getElementById('auto-detect-info');
    
    if (e.target.checked) {
      manualConfig.style.display = 'none';
      autoDetectInfo.style.display = 'block';
    } else {
      manualConfig.style.display = 'block';
      autoDetectInfo.style.display = 'none';
      // Load stored values when switching to manual
      chrome.storage.sync.get(['ragard_api_base_url', 'ragard_web_app_base_url'], (result) => {
        const apiUrl = result.ragard_api_base_url || window.ragardConfig?.PROD_API_BASE_URL || 'https://api.ragardai.com';
        const webAppUrl = result.ragard_web_app_base_url || window.ragardConfig?.PROD_WEB_APP_BASE_URL || 'https://ragardai.com';
        document.getElementById('api-base-url').value = apiUrl;
        document.getElementById('web-app-base-url').value = webAppUrl;
      });
    }
  });
  
  document.getElementById('save-settings').addEventListener('click', saveSettings);
  document.getElementById('test-connection').addEventListener('click', testConnection);
});

